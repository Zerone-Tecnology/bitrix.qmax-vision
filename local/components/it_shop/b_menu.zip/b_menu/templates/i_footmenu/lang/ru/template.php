<?
	$MESS['I_SHOW_FOOTMENU'] = 'Показать все';
	$MESS['I_HIDE_FOOTMENU'] = 'Скрыть';
?>