<?
$MESS['I_MENU'] = "Меню";
?>