<?if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true)die();
// ---------------------------------------------------------------------------------------------------- iLaB
$arTemplateParameters = array(
	'I_POINT'		=> array(
		'PARENT'	=> 'ILAB_SHOP',
		'NAME'		=> GetMessage('I_POINT_NAME'),
		'TYPE'		=> 'STRING',
		'DEFAULT'	=> '8'
	)
);
// ---------------------------------------------------------------------------------------------------- iLaB?>