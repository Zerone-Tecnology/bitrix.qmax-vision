<?
$MESS ['MAIN_MENU_ITEMS_NAME'] = "Меню";
$MESS ['MAIN_MENU_ITEMS_DESC'] = "Выводит меню указанного типа";
$MESS ['MAIN_NAVIGATION_SERVICE'] = "Навигация";
?>