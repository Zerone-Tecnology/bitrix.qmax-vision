<?
$MESS["MAIN_MENU_EDIT"] = "Редактировать пункты меню";
$MESS["MAIN_MENU_ADD"] = "Добавить пункты меню";
$MESS["MAIN_MENU_ADD_NEW"] = "Создать меню в текущем разделе";
$MESS["MAIN_MENU_TOP_PANEL_BUTTON_TEXT"] = "Меню";
$MESS["MAIN_MENU_TOP_PANEL_BUTTON_ALT"] = "Редактировать пункты меню";
$MESS["MAIN_MENU_TOP_PANEL_BUTTON_HINT"] = "Вызов формы редактирования меню. Нажмите на стрелку, чтобы отредактировать все меню данной страницы или создать новое меню.";
$MESS["MAIN_MENU_TOP_PANEL_ITEM_TEXT"] = "Редактировать \"#MENU_TITLE#\"";
$MESS["MAIN_MENU_TOP_PANEL_ITEM_ALT"] = "Редактировать пункты меню \"#MENU_TITLE#\"";
$MESS["MAIN_MENU_ADD_TOP_PANEL_ITEM_TEXT"] = "Создать \"#MENU_TITLE#\"";
$MESS["MAIN_MENU_ADD_TOP_PANEL_ITEM_ALT"] = "Создать меню \"#MENU_TITLE#\" в текущем разделе";
$MESS["MAIN_MENU_DEL_TOP_PANEL_ITEM_TEXT"] = "Удалить \"#MENU_TITLE#\"";
$MESS["MAIN_MENU_DEL_TOP_PANEL_ITEM_ALT"] = "Удалить меню \"#MENU_TITLE#\" в текущем разделе";
$MESS["menu_comp_del_menu"] = "Удалить меню в текущем разделе";
$MESS["menu_comp_del_conf"] = "Удалить файл меню \"#MENU_TITLE#\" в текущем разделе?";
?>