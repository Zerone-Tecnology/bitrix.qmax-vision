<?
$MESS["MAIN_MENU_EDIT"] = "Modify menu items";
$MESS["MAIN_MENU_ADD"] = "Add menu items";
$MESS["MAIN_MENU_ADD_NEW"] = "Create menu in current section";
$MESS["MAIN_MENU_TOP_PANEL_BUTTON_TEXT"] = "Menu";
$MESS["MAIN_MENU_TOP_PANEL_BUTTON_ALT"] = "Edit menu items";
$MESS["MAIN_MENU_TOP_PANEL_BUTTON_HINT"] = "Opens the menu editing form. Click the arrow to edit all the current page menus or create a new menu.";
$MESS["MAIN_MENU_TOP_PANEL_ITEM_TEXT"] = "Edit #MENU_TITLE#";
$MESS["MAIN_MENU_TOP_PANEL_ITEM_ALT"] = "Edit items of \"#MENU_TITLE#\" menu";
$MESS["MAIN_MENU_ADD_TOP_PANEL_ITEM_TEXT"] = "Create #MENU_TITLE#";
$MESS["MAIN_MENU_ADD_TOP_PANEL_ITEM_ALT"] = "Create \"#MENU_TITLE#\" menu in current section";
$MESS["MAIN_MENU_DEL_TOP_PANEL_ITEM_TEXT"] = "Delete \"#MENU_TITLE#\"";
$MESS["MAIN_MENU_DEL_TOP_PANEL_ITEM_ALT"] = "Delete menu \"#MENU_TITLE#\" in the current section";
$MESS["menu_comp_del_menu"] = "Delete menu in the current section";
$MESS["menu_comp_del_conf"] = "Do you want to delete the menu file \"#MENU_TITLE#\" in the current section?";
?>