<?
$MESS["MAIN_MENU_TYPE_NAME"] = "Menu type for root level";
$MESS["CHILD_MENU_TYPE_NAME"] = "Menu type for child levels";
$MESS["FILEMAN_OPTION_LEFT_MENU_NAME"] = "Left menu";
$MESS["FILEMAN_OPTION_TOP_MENU_NAME"] = "Upper menu";
$MESS["MAX_LEVEL_NAME"] = "Menu depth level";
$MESS["USE_EXT_NAME"] = "Use files .menu-type.menu_ext.php for menus";
$MESS["DELAY_NAME"] = "Delay building of menu template";
$MESS["CP_BM_MENU_CACHE_USE_GROUPS"] = "Respect Access Permissions";
$MESS["CP_BM_MENU_CACHE_GET_VARS"] = "Important query variables";
$MESS["comp_menu_allow_multi_select"] = "Allow several menu items to be highlighted as active";

// ---------------------------------------------------------------------------------------------------- iLaB
$MESS['ILAB_SHOP'] = 'Настройки интернет-магазина iLab shop';
?>