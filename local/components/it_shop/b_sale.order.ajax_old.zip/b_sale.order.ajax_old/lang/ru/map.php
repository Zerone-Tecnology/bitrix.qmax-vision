<?
$MESS['MAP_PHONE'] = "Телефон";
$MESS['MAP_ADRES'] = "Адрес";
$MESS['MAP_WORK'] = "Режим работы";
$MESS['MAP_STORE'] = "Склад";
$MESS['MAP_EMAIL'] = "Электронная почта";
$MESS['MAP_DESC'] = "Описание";
?>