<?
$MESS["MAP_PHONE"] = "Phone";
$MESS["MAP_ADRES"] = "Address";
$MESS["MAP_WORK"] = "Business hours";
$MESS["MAP_STORE"] = "Warehouse";
$MESS["MAP_EMAIL"] = "E-Mail";
$MESS["MAP_DESC"] = "Description";
?>