// ------------------------------------------ проверка email
$('.j_request_email').keyup(function(){
	var th = $(this);
	var wrap = th.siblings('.j_response_email');
	var email = th.val();
	if(email != '') {
		var pattern = /^([a-z0-9_\.-])+@[a-z0-9-]+\.([a-z]{2,4}\.)?[a-z]{2,4}$/i;
		if(pattern.test(email))
		{
			$.post(
				"/local/templates/ilab_it_shop/tmpl/ajax/email_verification.php",
				{
					email: email
				},
				onAjaxSuccess
			);
			function onAjaxSuccess(data)
			{
				if(data != 'false')
				{
					wrap.find('.j_response_email_title').html('Авторизуйтесь, пожалуйста');
					wrap.removeClass('idnone');
					wrap.find('.j_response_email_content').removeClass('idnone');
					$.post(
						"/local/templates/ilab_it_shop/tmpl/ajax/authform.php",
						"",
						function(ed)
						{
							wrap.find('.j_response_email_content').html(ed);
						}
					);
				}
				else
				{
					wrap.find('.j_response_email_title').html('Аккаунт свободен');
					wrap.removeClass('idnone');
					wrap.find('.j_response_email_content').addClass('idnone');
				}
			}
		}
		else
		{
			wrap.find('.j_response_email_title').html('Введите правильные данные');
			wrap.find('.j_response_email_content').addClass('idnone');
			wrap.removeClass('idnone');
		}
	}
});