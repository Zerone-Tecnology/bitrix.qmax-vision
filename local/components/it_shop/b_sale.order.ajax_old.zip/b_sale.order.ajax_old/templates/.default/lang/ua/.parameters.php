<?
$MESS["T_IMG_WIDTH"] = "Ширина картинки товару";
$MESS["T_IMG_HEIGHT"] = "Висота картинки товару";
$MESS["T_PAYMENT_SERVICES_NAMES"] = "Показувати назви платіжних систем";
$MESS["T_ALLOW_NEW_PROFILE"] = "Дозволити безліч профілів покупців";
$MESS["T_SHOW_STORES_IMAGES"] = "Показувати зображення складів у вікні вибору пункту видачі";
?>