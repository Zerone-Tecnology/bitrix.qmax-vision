<?
$MESS["T_IMG_WIDTH"] = "Product image width";
$MESS["T_IMG_HEIGHT"] = "Product image height";
$MESS["T_PAYMENT_SERVICES_NAMES"] = "Show payment system names";
$MESS["T_ALLOW_NEW_PROFILE"] = "Allow multiple customer profiles";
$MESS["T_SHOW_STORES_IMAGES"] = "Show warehouse images in pick-up point selection form";
?>