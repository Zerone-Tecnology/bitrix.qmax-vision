<?if(!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();
// ---------------------------------------------------------------------------------------------------- iLaB
if($arResult['ITEMS']):
	$co		= count($arResult['ITEMS']);
	$w		= floor( 940/$co );
	$l_w	= ($w+940)-( $w*$co );
	$frame	= $this->createFrame('jq_hmenu', false)->begin();

	function i_h_view_cat($data, $arParams, $arOptions)
	{
		foreach ($data as $menu):
			$DL = $menu['DEPTH_LEVEL'];

				if( $DL!=1 ):?>
					<div class="i_hmenu_div_<?=$DL?> jq_hmenu_div_<?=$DL?>">
						<a href="<?=$menu['SECTION_PAGE_URL']?>" class="i_hmenu_a_<?=$DL;if($DL==1 && $menu['I_CHILD'])echo ' i_hmenu_arrow jq_hmenu_arrow';if($menu['I_SELECTED'])echo ' i_hmac_'.$menu['DEPTH_LEVEL']?>">
							<span><?echo $menu['NAME'];if( ($DL==1 && $arParams['I_NUMBER_ELEMENT_1LVL']=='Y') || ($DL>1 && $arParams['I_NUMBER_ELEMENT_NLVL']=='Y') )echo ' ('.$menu['ELEMENT_CNT'].')'?></span>
						</a>
				<?endif?>

						<?if($menu['I_CHILD']):?>

							<div class="i_hsub_<?=$DL?> jq_hsub_<?=$DL;if($DL==1)echo ' ivhid'?>" jq_hm_open="<?=$menu['ID']?>"<?if( $menu['UF_COLUM_MENU'] )echo ' jq_hm_col="'.$menu['UF_COLUM_MENU'].'" style="width:'.$menu['I_COLUM_WIDTH'].'px"'?>>
								<?if($menu['I_PRODUCT'])
									echo '<div class="i_vmline ipabs"></div>'?>
								<?if($DL==1)echo '<div class="jq_hor_shapeshift iprel">'//jq_shapeshift?>
								<?if($menu['I_PRODUCT'])
									i_showItem($APPLICATION, array('FROM'=>'MENU'), $menu['I_PRODUCT'], $arParams);// path of function - /local/templates/ilab_it_shop/tmpl/php/item.php

									i_h_view_cat($menu['I_CHILD'], $arParams, array());

								if($DL==1)echo '</div>'?>
							</div>
						<?endif?>

				<?if( $DL!=1 )echo '</div>'?>
		<?endforeach;
	}?>

<?/*$frame->beginStub()?>
	<div class="i_comp_loader"></div>
<?*/$frame->end()?>

	<nav class="i_hmenu jq_hmenu iprel<?if($arParams['I_MENU_LINE']=='Y')echo ' i_hmenu_line';if($arParams['I_COLOR_SCHEME']=='Y')echo ' i_hmenu_color'?>">

		<?$i=1;foreach($arResult['ITEMS'] as $e):
			$DL = $e['DEPTH_LEVEL'];
			// Инвертация картинок
			if( $e['I_WHITE'] && $arParams['I_COLOR_SCHEME']=='Y' && $arParams['I_REVERSE_IMAGE']=='Y' ) {
				$first		= $e['~PICTURE'];
				$second		= $e['I_WHITE'];
			} else {
				$first		= $e['I_WHITE'];
				$second		= $e['~PICTURE'];
			}?>

				<a href="<?=$e['SECTION_PAGE_URL']?>" class="i_hmenu_a_<?=$DL;if( $DL==1 && $e['I_CHILD'] )echo ' jq_hmenu_arrow';if( $e['I_SELECTED'] )echo ' i_hmac_'.$e['DEPTH_LEVEL'];if( $e['~PICTURE'] && ($arParams['I_REMOVE_ICON']=='N') )echo ' iveralti'?>"<?if( $DL==1 && $i==$co)echo ' style="width:'.$l_w.'px"';elseif( $DL==1 )echo ' style="width:'.$w.'px"';if($DL==1 && $e['I_CHILD'])echo ' jq_hm_open="'.$e['ID'].'"'?>>
					<div class="i_hmenu_out_1 iprel">
						<?if( $arParams['I_MENU_ICON_TOP']=='Y' ):?>
							<?if( $e['~PICTURE'] && ($arParams['I_REMOVE_ICON']=='N') ):?>
								<div class="i_hmenu_vimg_1">
									<?if( $e['I_WHITE'] && $arParams['I_COLOR_SCHEME']=='Y' )
										echo CFile::ShowImage($first, 100, 100, 'class="i_hm_img_white"').CFile::ShowImage($second, 100, 100, 'class="i_hm_img_color idnone"');
									else
										echo CFile::ShowImage($e['~PICTURE'], 100, 100)?>
								</div>
							<?endif?>
							<span class="i_hmenu_vspan_1"><span><?echo $e['NAME'];if( $arParams['I_NUMBER_ELEMENT_1LVL']=='Y' )echo ' ('.$e['ELEMENT_CNT'].')'?></span></span>
						<?else:?>
							<?if( $e['~PICTURE'] && ($arParams['I_REMOVE_ICON']=='N') ):?>
								<div class="i_hmenu_img_1">
									<?if( $e['I_WHITE'] && $arParams['I_COLOR_SCHEME']=='Y' )
										echo CFile::ShowImage($first, 100, 100, 'class="i_hm_img_white"').CFile::ShowImage($second, 100, 100, 'class="i_hm_img_color idnone"');
									else
										echo CFile::ShowImage($e['~PICTURE'], 100, 100)?>
								</div>
							<?endif?>
							<div class="i_hmenu_span_1"><span><?echo $e['NAME'];if( $arParams['I_NUMBER_ELEMENT_1LVL']=='Y' )echo ' ('.$e['ELEMENT_CNT'].')'?></span></div>
						<?endif?>
					</div>
					<?if( $DL==1 && $e['I_CHILD'] )echo '<div class="i_hmenu_arrow"></div>'?>
				</a>

		<?$i++;endforeach?>

		<div class="i_hmenu_drop ipabs">
			<?i_h_view_cat( $arResult['ITEMS'], $arParams, array('I_COUNT'=>$w) )?>
		</div>
	</nav>

<?endif
// ---------------------------------------------------------------------------------------------------- iLaB?>





<?/*if($USER->isAdmin()):?>
	<pre><?print_r($arResult)?></pre>
<?endif*/?>