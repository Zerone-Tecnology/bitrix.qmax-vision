<?
use Bitrix\Main\Loader;
use Bitrix\Currency\CurrencyTable;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED!==true) die();
// Не волнуйтесь, если что-то не работает. Если бы всё работало, Вас бы уволили.
// ---------------------------------------------------------------------------------------------------- iLaB
$dir = $arParams['I_DIR'];//array_values( array_filter( explode( '/', $arParams['I_DIR'] ) ) );// В каком разделе находимся
$arResult['dir'] = $dir;
$l = strtoupper(LANGUAGE_ID);

if ($this->StartResultCache(false, $arParams['CACHE_GROUPS']==='N'? false: $USER->GetGroups()))
{

	// CURRENCY
	$arParams['PRICE_VAT_INCLUDE']	= $arParams['PRICE_VAT_INCLUDE'] !== 'N';
	$arParams['CURRENCY_ID']		= trim(strval($arParams['CURRENCY_ID']));

	if ( $arParams['CURRENCY_ID']=='' )
		$arParams['CONVERT_CURRENCY'] = 'N';
	
	if ( $arParams['CONVERT_CURRENCY']=='Y' )
		if (!Loader::includeModule('currency'))
		{
			$arParams['CONVERT_CURRENCY']	= 'N';
			$arParams['CURRENCY_ID']		= '';
		} else {
			$currencyIterator = CurrencyTable::getList(array(
				'select' => array('CURRENCY'),
				'filter' => array('CURRENCY' => $arParams['CURRENCY_ID'])
			));
			if ($currency = $currencyIterator->fetch())
			{
				$arParams['CURRENCY_ID']		= $currency['CURRENCY'];
				$arConvertParams['CURRENCY_ID'] = $currency['CURRENCY'];
			}else {
				$arParams['CONVERT_CURRENCY']	= 'N';
				$arParams['CURRENCY_ID']		= '';
			}
			unset($currency, $currencyIterator);
		}

	$width_colum = 235;// (px) width one colum

// ---------------------------------------------------------------------------------------------------- Parameters Default Settings
	if( !$arParams['I_DEPTH_LEVEL'] || ($arParams['I_DEPTH_LEVEL']>4 || $arParams['I_DEPTH_LEVEL']<1)  )
		$I_DEPTH_LEVEL = 4;
	else
		$I_DEPTH_LEVEL = $arParams['I_DEPTH_LEVEL'];
// ---------------------------------------------------------------------------------------------------- Parameters Default Settings

	if( !CModule::IncludeModule('iblock') )
		return;

	$arPriceTools = CIBlockPriceTools::GetCatalogPrices($arParams['IBLOCK_ID'], $arParams['I_PRICE_CODE']);
	$i_arSelect	= Array('*');
	foreach($arPriceTools as $e)
		$i_arSelect[] = $e['SELECT'];

	$arSelect = Array('UF_IMG', 'UF_PRODUCT', 'UF_COLUM_MENU', 'UF_NAME', 'UF_IMG_WHITE', 'UF_I_NAME_KZ', 'UF_I_NAME_RU', 'UF_I_NAME_EN');
	$arFilter = Array('IBLOCK_ID'=>$arParams['IBLOCK_ID'], 'ACTIVE'=>'Y', 'GLOBAL_ACTIVE'=>'Y', '<=DEPTH_LEVEL'=>$I_DEPTH_LEVEL, 'CNT_ACTIVE'=>'Y');

	/*if( $arParams['I_SHOW_SECT_MENU'] )
		$arFilter['!ID'] = $arParams['I_SHOW_SECT_MENU'];*/

	$res = CIBlockSection::GetList(Array('SORT'=>'ASC', 'NAME'=>'ASC'), $arFilter, true, $arSelect);
	while($ob = $res->GetNextElement())
	{
		$ob_do = $ob->GetFields();

		$ob_do['~PICTURE'] = CFile::GetPath($ob_do['PICTURE']);

		if( $ob_do['~UF_NAME'] )
			$ob_do['NAME']		= $ob_do['~UF_NAME'];

		if( $ob_do['UF_I_NAME_'.$l] )
			$ob_do['NAME'] = $ob_do['UF_I_NAME_'.$l];

		if( $ob_do['UF_IMG_WHITE'] )
			$ob_do['I_WHITE']	= CFile::GetPath($ob_do['UF_IMG_WHITE']);

		// Colum menu
		if( $ob_do['UF_COLUM_MENU'] )
		{
			if( $ob_do['UF_COLUM_MENU']>4 )// max 4 columns (default to javascript)
				$ob_do['UF_COLUM_MENU'] = 4;

			if( $ob_do['UF_PRODUCT'] && $ob_do['UF_COLUM_MENU']>3 )// max 3 colums if product (default to javascript)
				$ob_do['UF_COLUM_MENU'] = 3;

			// width colum
			$ob_do['I_COLUM_WIDTH'] = $ob_do['UF_COLUM_MENU']*$width_colum;
			if( $ob_do['UF_PRODUCT'] )
				$ob_do['I_COLUM_WIDTH'] = $ob_do['I_COLUM_WIDTH']+$width_colum;
		}

// ---------------------------------------------------------------------------------------------------- GOODS
		if($ob_do['UF_PRODUCT'])// Товар в меню
		{
			$i_arOrder		= Array('RAND'=>'ASC');
			$i_arFilter		= Array('IBLOCK_ID'=>$arParams['IBLOCK_ID'], 'ID'=>$ob_do['UF_PRODUCT'], 'ACTIVE'=>'Y');
			$i_arNav		= Array('nTopCount'=>1);
			$ires = CIBlockElement::GetList($i_arOrder, $i_arFilter, false, $i_arNav, $i_arSelect);
			while($iob = $ires->GetNextElement())
			{
				$iob_do					= $iob->GetFields();
				$iob_do['PROPERTIES']	= $iob->GetProperties();

				//IMG
				$iob_do['PREVIEW_PICTURE'] = array();
	$iob_do['PREVIEW_PICTURE']['SRC']	= CFile::GetPath($iob_do['~PREVIEW_PICTURE']);

				// PRICES
				$iob_do['PRICES']		= CIBlockPriceTools::GetItemPrices(	$arParams['IBLOCK_ID'], $arPriceTools, $iob_do, $arParams['PRICE_VAT_INCLUDE'], $arConvertParams);
				$iob_do['CAN_BUY']		= CIBlockPriceTools::CanBuy(		$arParams['IBLOCK_ID'], $arPriceTools, $iob_do);
				// MIN_PRICE
				if( $iob_do['PRICES'] )
					foreach($iob_do['PRICES'] as $p)
						if($p['MIN_PRICE']=='Y')
						{	$iob_do['MIN_PRICE'] = $p;	break;	}

				// EDIT
				$arButtons = CIBlock::GetPanelButtons(
					$iob_do['IBLOCK_ID'],
					$iob_do['ID'],
					$iob_do['IBLOCK_SECTION_ID'],
					array('SECTION_BUTTONS'=>false, 'SESSID'=>false)
				);
				$iob_do['EDIT_LINK']	= $arButtons['edit']['edit_element']['ACTION_URL'];
				$iob_do['DELETE_LINK']	= $arButtons['edit']['delete_element']['ACTION_URL'];

				$rsRatios = CCatalogMeasureRatio::getList(
					array(),
					array('PRODUCT_ID' => $iob_do['ID']),
					false,
					false,
					array('PRODUCT_ID', 'RATIO')
				);
				while ($arRatio = $rsRatios->Fetch())
				{
					$arRatio['PRODUCT_ID'] = (int)$arRatio['PRODUCT_ID'];

					$intRatio = (int)$arRatio['RATIO'];
					$dblRatio = doubleval($arRatio['RATIO']);
					$mxRatio = ($dblRatio > $intRatio ? $dblRatio : $intRatio);
					if (CATALOG_VALUE_EPSILON > abs($mxRatio))
						$mxRatio = 1;
					elseif (0 > $mxRatio)
						$mxRatio = 1;
					$iob_do['CATALOG_MEASURE_RATIO'] = $mxRatio;
				}

				$ob_do['I_PRODUCT']		= $iob_do;
			}
		}
// ---------------------------------------------------------------------------------------------------- GOODS

		// SELECTED
		if(mb_strpos($dir, $ob_do['SECTION_PAGE_URL'])!==false)
		{
			$ob_do['I_SELECTED'] = 'Y';
//			echo $ob_do['ID'].'-'.$ob_do['DEPTH_LEVEL'].'|';
			if( $ob_do['IBLOCK_SECTION_ID'] )
				$id = $ob_do['IBLOCK_SECTION_ID'];
		}
		$arRe[$ob_do['ID']] = $ob_do;
	}

	// SELECTED
	if( $id )
	{
		$res = CIBlockSection::GetNavChain( false, $id );
		while($ob = $res->GetNext())
			if( $ob['DEPTH_LEVEL']==1 )
				$arRe[$ob['ID']]['I_SELECTED'] = 'Y';
	}
		/*do{
			echo $arRe[$id]['DEPTH_LEVEL'].'==1<br>';
			$arRe[$id]['I_SELECTED'] = 'Y';
			$id = $arRe[$id]['IBLOCK_SECTION_ID'];
			
		}while( $arRe[$id]['DEPTH_LEVEL']<1 );*/

	$arResult['ITEMS'] = i_mapTree($arRe);

	if( $arParams['I_SHOW_SECT_MENU'] )
		foreach ($arResult['ITEMS'] as $k=>$e)
			if( in_array($k, $arParams['I_SHOW_SECT_MENU']) )
				unset($arResult['ITEMS'][$k]);

	$this->IncludeComponentTemplate();
	return $arResult;
}
// ---------------------------------------------------------------------------------------------------- iLaB
/*
	$arSelect = Array('ID', 'NAME', 'IBLOCK_SECTION_ID');
	$arFilter = Array('IBLOCK_ID'=>$arParams[''], 'ACTIVE'=>'Y');
	$res = CIBlockSection::GetList(Array('SORT'=>'ASC'), $arFilter, false, $arSelect);
	$res = CIBlockElement::GetList(Array('SORT'=>'ASC'), $arFilter, false, false, $arSelect);
	while($ob = $res->GetNextElement())
	{

		$ob_do			= $ob->GetFields();
		$ob_do['PRO']	= $ob->GetProperties();

		$arButtons = CIBlock::GetPanelButtons(
			$ob_do['IBLOCK_ID'],
			$ob_do['ID'],
			$arResult['ID'],
			array('SECTION_BUTTONS'=>false, 'SESSID'=>false, 'CATALOG'=>true)
		);
		$ob_do['EDIT_LINK']		= $arButtons['edit']['edit_element']['ACTION_URL'];
		$ob_do['DELETE_LINK']	= $arButtons['edit']['delete_element']['ACTION_URL'];
	}

	$arParams['']
	$arResult['']
*/
// ---------------------------------------------------------------------------------------------------- iLaB?>